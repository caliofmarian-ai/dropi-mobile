# Merchant_Terms.md

