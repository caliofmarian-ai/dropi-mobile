import React, { useEffect, useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Provider as ReduxProvider } from 'react-redux';
import { PaperProvider } from 'react-native-paper';
import AsyncStorage from '@react-native-async-storage/async-storage';
import store from './store';

// Screens
import LoginScreen from './screens/auth/LoginScreen';
import RegisterScreen from './screens/auth/RegisterScreen';
import SplashScreen from './screens/SplashScreen';

// Dashboard Screens
import CustomerDashboard from './screens/dashboards/CustomerDashboard';
import MerchantDashboard from './screens/dashboards/MerchantDashboard';
import PilotDashboard from './screens/dashboards/PilotDashboard';
import OperatorDashboard from './screens/dashboards/OperatorDashboard';
import AdminDashboard from './screens/dashboards/AdminDashboard';

// Feature Screens
import OrdersScreen from './screens/features/OrdersScreen';
import DeliveriesScreen from './screens/features/DeliveriesScreen';
import SupportScreen from './screens/features/SupportScreen';
import ProfileScreen from './screens/features/ProfileScreen';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

// Auth Stack
function AuthStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
        animationEnabled: true,
      }}
    >
      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen name="Register" component={RegisterScreen} />
    </Stack.Navigator>
  );
}

// Dashboard Stack based on user role
function DashboardStack({ userRole }) {
  const dashboards = {
    customer: CustomerDashboard,
    merchant: MerchantDashboard,
    pilot: PilotDashboard,
    operator: OperatorDashboard,
    admin: AdminDashboard,
  };

  const Dashboard = dashboards[userRole] || CustomerDashboard;

  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: true,
        tabBarActiveTintColor: '#007AFF',
        tabBarInactiveTintColor: '#999',
      }}
    >
      <Tab.Screen
        name="Dashboard"
        component={Dashboard}
        options={{
          tabBarLabel: 'Home',
          tabBarIcon: ({ color }) => <Icon name="home" color={color} />,
        }}
      />
      <Tab.Screen
        name="Orders"
        component={OrdersScreen}
        options={{
          tabBarLabel: 'Orders',
          tabBarIcon: ({ color }) => <Icon name="package" color={color} />,
        }}
      />
      <Tab.Screen
        name="Deliveries"
        component={DeliveriesScreen}
        options={{
          tabBarLabel: 'Deliveries',
          tabBarIcon: ({ color }) => <Icon name="truck" color={color} />,
        }}
      />
      <Tab.Screen
        name="Support"
        component={SupportScreen}
        options={{
          tabBarLabel: 'Support',
          tabBarIcon: ({ color }) => <Icon name="headset" color={color} />,
        }}
      />
      <Tab.Screen
        name="Profile"
        component={ProfileScreen}
        options={{
          tabBarLabel: 'Profile',
          tabBarIcon: ({ color }) => <Icon name="user" color={color} />,
        }}
      />
    </Tab.Navigator>
  );
}

// Main App Component
export default function App() {
  const [isLoading, setIsLoading] = useState(true);
  const [userToken, setUserToken] = useState(null);
  const [userRole, setUserRole] = useState('customer');

  useEffect(() => {
    bootstrapAsync();
  }, []);

  const bootstrapAsync = async () => {
    try {
      // Check if user is logged in
      const token = await AsyncStorage.getItem('userToken');
      const role = await AsyncStorage.getItem('userRole');
      
      if (token) {
        setUserToken(token);
        setUserRole(role || 'customer');
      }
    } catch (e) {
      console.error('Failed to restore token', e);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return <SplashScreen />;
  }

  return (
    <ReduxProvider store={store}>
      <PaperProvider>
        <NavigationContainer>
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            {userToken == null ? (
              <Stack.Screen
                name="Auth"
                component={AuthStack}
                options={{
                  animationEnabled: false,
                }}
              />
            ) : (
              <Stack.Screen
                name="App"
                children={() => <DashboardStack userRole={userRole} />}
                options={{
                  animationEnabled: false,
                }}
              />
            )}
          </Stack.Navigator>
        </NavigationContainer>
      </PaperProvider>
    </ReduxProvider>
  );
}

// Placeholder Icon component
function Icon({ name, color }) {
  return <Text style={{ color, fontSize: 24 }}>📱</Text>;
}
