import { createSlice } from '@reduxjs/toolkit';

const deliveriesSlice = createSlice({
  name: 'deliveries',
  initialState: {
    items: [],
    isLoading: false,
    error: null,
  },
  reducers: {
    setDeliveries: (state, action) => {
      state.items = action.payload;
    },
    updateDelivery: (state, action) => {
      const index = state.items.findIndex(d => d.id === action.payload.id);
      if (index !== -1) {
        state.items[index] = action.payload;
      }
    },
    setLoading: (state, action) => {
      state.isLoading = action.payload;
    },
  },
});

export const { setDeliveries, updateDelivery, setLoading } = deliveriesSlice.actions;
export default deliveriesSlice.reducer;
