import { configureStore } from '@reduxjs/toolkit';
import authReducer from './slices/authSlice';
import ordersReducer from './slices/ordersSlice';
import deliveriesReducer from './slices/deliveriesSlice';
import uiReducer from './slices/uiSlice';

const store = configureStore({
  reducer: {
    auth: authReducer,
    orders: ordersReducer,
    deliveries: deliveriesReducer,
    ui: uiReducer,
  },
});

export default store;
