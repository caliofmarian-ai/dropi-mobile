import jwt from 'jsonwebtoken';
import { getDatabase } from './db/index.js';

export async function createContext({ req, res }) {
  const db = getDatabase();
  
  // Extract token from Authorization header
  const authHeader = req.headers.authorization;
  const token = authHeader?.split(' ')[1];
  
  let user = null;
  
  if (token) {
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET || 'secret');
      user = {
        id: decoded.userId,
        email: decoded.email,
        role: decoded.role,
        channel: decoded.channel,
        agentType: decoded.agentType,
      };
    } catch (err) {
      console.error('Token verification failed:', err.message);
    }
  }
  
  return {
    db,
    user,
    req,
    res,
    isAuthenticated: !!user,
  };
}
