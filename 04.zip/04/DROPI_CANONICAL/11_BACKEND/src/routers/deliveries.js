import { router, publicProcedure, protectedProcedure, adminProcedure } from '../trpc.js';
import { z } from 'zod';

export const deliveriesRouter = router({
  list: publicProcedure.query(async ({ ctx }) => {
    return { message: 'deliveries list endpoint' };
  }),
});
