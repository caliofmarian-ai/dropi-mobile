import { z } from 'zod';
import { publicProcedure, protectedProcedure, router } from '../trpc';
import { db } from '../db';
import { orders, deliveries, merchants, customers } from '../db/schema';
import { eq, and } from 'drizzle-orm';

export const marketplaceRouter = router({
  // Create order (customer)
  createOrder: protectedProcedure
    .input(z.object({
      merchantId: z.string(),
      items: z.array(z.object({
        productId: z.string(),
        quantity: z.number(),
        price: z.number(),
      })),
      deliveryAddress: z.string(),
      totalAmount: z.number(),
    }))
    .mutation(async ({ input, ctx }) => {
      if (ctx.user.role !== 'user' && ctx.user.role !== 'customer') {
        throw new Error('Only customers can create orders');
      }

      const [order] = await db
        .insert(orders)
        .values({
          customerId: ctx.user.id,
          merchantId: input.merchantId,
          status: 'pending',
          totalAmount: input.totalAmount,
          itemsCount: input.items.length,
          deliveryAddress: input.deliveryAddress,
          createdAt: new Date(),
          updatedAt: new Date(),
        })
        .returning();

      return {
        id: order.id,
        status: order.status,
        totalAmount: order.totalAmount,
        createdAt: order.createdAt,
      };
    }),

  // Get customer orders
  getMyOrders: protectedProcedure
    .input(z.object({
      status: z.string().optional(),
      limit: z.number().default(50),
      offset: z.number().default(0),
    }))
    .query(async ({ input, ctx }) => {
      let query = db
        .select()
        .from(orders)
        .where(eq(orders.customerId, ctx.user.id));

      if (input.status) {
        query = query.where(eq(orders.status, input.status));
      }

      const allOrders = await query;
      const paginatedOrders = allOrders.slice(input.offset, input.offset + input.limit);

      return {
        total: allOrders.length,
        orders: paginatedOrders.map(o => ({
          id: o.id,
          status: o.status,
          totalAmount: o.totalAmount,
          itemsCount: o.itemsCount,
          deliveryAddress: o.deliveryAddress,
          createdAt: o.createdAt,
          updatedAt: o.updatedAt,
        })),
      };
    }),

  // Get merchant orders
  getMerchantOrders: protectedProcedure
    .input(z.object({
      status: z.string().optional(),
      limit: z.number().default(50),
      offset: z.number().default(0),
    }))
    .query(async ({ input, ctx }) => {
      if (ctx.user.role !== 'merchant') {
        throw new Error('Only merchants can view merchant orders');
      }

      let query = db
        .select()
        .from(orders)
        .where(eq(orders.merchantId, ctx.user.id));

      if (input.status) {
        query = query.where(eq(orders.status, input.status));
      }

      const allOrders = await query;
      const paginatedOrders = allOrders.slice(input.offset, input.offset + input.limit);

      return {
        total: allOrders.length,
        orders: paginatedOrders.map(o => ({
          id: o.id,
          status: o.status,
          totalAmount: o.totalAmount,
          itemsCount: o.itemsCount,
          createdAt: o.createdAt,
        })),
      };
    }),

  // Update order status (merchant)
  updateOrderStatus: protectedProcedure
    .input(z.object({
      orderId: z.string(),
      status: z.enum(['pending', 'confirmed', 'preparing', 'ready', 'picked', 'delivered', 'cancelled']),
    }))
    .mutation(async ({ input, ctx }) => {
      if (ctx.user.role !== 'merchant') {
        throw new Error('Only merchants can update order status');
      }

      const [order] = await db
        .select()
        .from(orders)
        .where(eq(orders.id, input.orderId));

      if (!order || order.merchantId !== ctx.user.id) {
        throw new Error('Order not found or unauthorized');
      }

      const [updatedOrder] = await db
        .update(orders)
        .set({
          status: input.status,
          updatedAt: new Date(),
        })
        .where(eq(orders.id, input.orderId))
        .returning();

      return {
        id: updatedOrder.id,
        status: updatedOrder.status,
        updatedAt: updatedOrder.updatedAt,
      };
    }),

  // Create delivery (pilot)
  createDelivery: protectedProcedure
    .input(z.object({
      orderId: z.string(),
      droneId: z.string(),
      estimatedTime: z.number(), // in minutes
      route: z.array(z.object({
        latitude: z.number(),
        longitude: z.number(),
      })),
    }))
    .mutation(async ({ input, ctx }) => {
      if (ctx.user.role !== 'pilot') {
        throw new Error('Only pilots can create deliveries');
      }

      const [delivery] = await db
        .insert(deliveries)
        .values({
          orderId: input.orderId,
          pilotId: ctx.user.id,
          droneId: input.droneId,
          status: 'assigned',
          estimatedTime: input.estimatedTime,
          createdAt: new Date(),
          updatedAt: new Date(),
        })
        .returning();

      return {
        id: delivery.id,
        status: delivery.status,
        estimatedTime: delivery.estimatedTime,
        createdAt: delivery.createdAt,
      };
    }),

  // Get pilot deliveries
  getMyDeliveries: protectedProcedure
    .input(z.object({
      status: z.string().optional(),
      limit: z.number().default(50),
      offset: z.number().default(0),
    }))
    .query(async ({ input, ctx }) => {
      if (ctx.user.role !== 'pilot') {
        throw new Error('Only pilots can view their deliveries');
      }

      let query = db
        .select()
        .from(deliveries)
        .where(eq(deliveries.pilotId, ctx.user.id));

      if (input.status) {
        query = query.where(eq(deliveries.status, input.status));
      }

      const allDeliveries = await query;
      const paginatedDeliveries = allDeliveries.slice(input.offset, input.offset + input.limit);

      return {
        total: allDeliveries.length,
        deliveries: paginatedDeliveries.map(d => ({
          id: d.id,
          orderId: d.orderId,
          status: d.status,
          estimatedTime: d.estimatedTime,
          actualTime: d.actualTime,
          createdAt: d.createdAt,
        })),
      };
    }),

  // Update delivery status
  updateDeliveryStatus: protectedProcedure
    .input(z.object({
      deliveryId: z.string(),
      status: z.enum(['assigned', 'in_transit', 'arrived', 'completed', 'failed']),
      actualTime: z.number().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      if (ctx.user.role !== 'pilot') {
        throw new Error('Only pilots can update delivery status');
      }

      const [delivery] = await db
        .select()
        .from(deliveries)
        .where(eq(deliveries.id, input.deliveryId));

      if (!delivery || delivery.pilotId !== ctx.user.id) {
        throw new Error('Delivery not found or unauthorized');
      }

      const [updatedDelivery] = await db
        .update(deliveries)
        .set({
          status: input.status,
          actualTime: input.actualTime,
          updatedAt: new Date(),
        })
        .where(eq(deliveries.id, input.deliveryId))
        .returning();

      return {
        id: updatedDelivery.id,
        status: updatedDelivery.status,
        updatedAt: updatedDelivery.updatedAt,
      };
    }),

  // Get marketplace stats (admin)
  getMarketplaceStats: protectedProcedure
    .query(async ({ ctx }) => {
      if (ctx.user.role !== 'admin') {
        throw new Error('Only admins can view marketplace stats');
      }

      const allOrders = await db.select().from(orders);
      const allDeliveries = await db.select().from(deliveries);

      const totalOrders = allOrders.length;
      const totalRevenue = allOrders.reduce((sum, o) => sum + (o.totalAmount || 0), 0);
      const completedDeliveries = allDeliveries.filter(d => d.status === 'completed').length;
      const avgDeliveryTime = allDeliveries
        .filter(d => d.actualTime)
        .reduce((sum, d) => sum + (d.actualTime || 0), 0) / (allDeliveries.filter(d => d.actualTime).length || 1);

      return {
        totalOrders,
        totalRevenue,
        completedDeliveries,
        avgDeliveryTime: Math.round(avgDeliveryTime),
        ordersByStatus: {
          pending: allOrders.filter(o => o.status === 'pending').length,
          confirmed: allOrders.filter(o => o.status === 'confirmed').length,
          delivered: allOrders.filter(o => o.status === 'delivered').length,
          cancelled: allOrders.filter(o => o.status === 'cancelled').length,
        },
      };
    }),
});
