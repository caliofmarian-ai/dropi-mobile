import { router, publicProcedure, protectedProcedure, adminProcedure } from '../trpc.js';
import { z } from 'zod';

export const analyticsRouter = router({
  list: publicProcedure.query(async ({ ctx }) => {
    return { message: 'analytics list endpoint' };
  }),
});
