import { router, publicProcedure, protectedProcedure, adminProcedure } from '../trpc.js';
import { z } from 'zod';

export const simulationRouter = router({
  list: publicProcedure.query(async ({ ctx }) => {
    return { message: 'simulation list endpoint' };
  }),
});
