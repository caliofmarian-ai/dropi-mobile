import { z } from 'zod';
import { publicProcedure, protectedProcedure, router } from '../trpc';
import { db } from '../db';
import { users } from '../db/schema';
import { eq } from 'drizzle-orm';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';

export const authRouter = router({
  // Register new user
  register: publicProcedure
    .input(z.object({
      email: z.string().email(),
      password: z.string().min(8),
      name: z.string(),
      role: z.enum(['admin', 'user', 'merchant', 'pilot', 'operator']),
      channel: z.enum(['C1', 'C2', 'C3', 'ADMIN']),
    }))
    .mutation(async ({ input }) => {
      const hashedPassword = await bcrypt.hash(input.password, 10);
      
      const [existingUser] = await db
        .select()
        .from(users)
        .where(eq(users.email, input.email));
      
      if (existingUser) {
        throw new Error('User already exists');
      }

      const [newUser] = await db
        .insert(users)
        .values({
          email: input.email,
          password: hashedPassword,
          name: input.name,
          globalRole: input.role,
          userType: input.role,
          channel: input.channel,
          isActive: true,
          createdAt: new Date(),
          updatedAt: new Date(),
        })
        .returning();

      return {
        id: newUser.id,
        email: newUser.email,
        name: newUser.name,
        role: newUser.globalRole,
        channel: newUser.channel,
      };
    }),

  // Login user
  login: publicProcedure
    .input(z.object({
      email: z.string().email(),
      password: z.string(),
    }))
    .mutation(async ({ input }) => {
      const [user] = await db
        .select()
        .from(users)
        .where(eq(users.email, input.email));

      if (!user) {
        throw new Error('User not found');
      }

      const passwordMatch = await bcrypt.compare(input.password, user.password || '');
      if (!passwordMatch) {
        throw new Error('Invalid password');
      }

      const token = jwt.sign(
        {
          id: user.id,
          email: user.email,
          role: user.globalRole,
          channel: user.channel,
        },
        process.env.JWT_SECRET || 'secret',
        { expiresIn: '24h' }
      );

      return {
        token,
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.globalRole,
          channel: user.channel,
        },
      };
    }),

  // Get current user
  me: protectedProcedure
    .query(async ({ ctx }) => {
      const [user] = await db
        .select()
        .from(users)
        .where(eq(users.id, ctx.user.id));

      if (!user) {
        throw new Error('User not found');
      }

      return {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.globalRole,
        channel: user.channel,
        isActive: user.isActive,
      };
    }),

  // Update user profile
  updateProfile: protectedProcedure
    .input(z.object({
      name: z.string().optional(),
      phone: z.string().optional(),
      address: z.string().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const [updatedUser] = await db
        .update(users)
        .set({
          name: input.name,
          updatedAt: new Date(),
        })
        .where(eq(users.id, ctx.user.id))
        .returning();

      return {
        id: updatedUser.id,
        email: updatedUser.email,
        name: updatedUser.name,
        role: updatedUser.globalRole,
      };
    }),

  // Change password
  changePassword: protectedProcedure
    .input(z.object({
      oldPassword: z.string(),
      newPassword: z.string().min(8),
    }))
    .mutation(async ({ input, ctx }) => {
      const [user] = await db
        .select()
        .from(users)
        .where(eq(users.id, ctx.user.id));

      if (!user) {
        throw new Error('User not found');
      }

      const passwordMatch = await bcrypt.compare(input.oldPassword, user.password || '');
      if (!passwordMatch) {
        throw new Error('Invalid old password');
      }

      const hashedPassword = await bcrypt.hash(input.newPassword, 10);

      await db
        .update(users)
        .set({
          password: hashedPassword,
          updatedAt: new Date(),
        })
        .where(eq(users.id, ctx.user.id));

      return { success: true };
    }),

  // List all users (admin only)
  listUsers: protectedProcedure
    .input(z.object({
      role: z.string().optional(),
      channel: z.string().optional(),
      limit: z.number().default(50),
      offset: z.number().default(0),
    }))
    .query(async ({ input, ctx }) => {
      if (ctx.user.role !== 'admin') {
        throw new Error('Unauthorized');
      }

      let query = db.select().from(users);

      if (input.role) {
        query = query.where(eq(users.globalRole, input.role));
      }

      if (input.channel) {
        query = query.where(eq(users.channel, input.channel));
      }

      const allUsers = await query;
      const paginatedUsers = allUsers.slice(input.offset, input.offset + input.limit);

      return {
        total: allUsers.length,
        users: paginatedUsers.map(u => ({
          id: u.id,
          email: u.email,
          name: u.name,
          role: u.globalRole,
          channel: u.channel,
          isActive: u.isActive,
          createdAt: u.createdAt,
        })),
      };
    }),

  // Deactivate user (admin only)
  deactivateUser: protectedProcedure
    .input(z.object({
      userId: z.string(),
    }))
    .mutation(async ({ input, ctx }) => {
      if (ctx.user.role !== 'admin') {
        throw new Error('Unauthorized');
      }

      await db
        .update(users)
        .set({
          isActive: false,
          updatedAt: new Date(),
        })
        .where(eq(users.id, input.userId));

      return { success: true };
    }),
});
