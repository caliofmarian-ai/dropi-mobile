import { router, publicProcedure, protectedProcedure } from "../trpc";
import { z } from "zod";
import { db } from "../db";
import { orders, orderItems, deliveries } from "../db/schema";
import { eq, and } from "drizzle-orm";

export const ordersRouter = router({
  // Create new order
  createOrder: protectedProcedure
    .input(
      z.object({
        merchantId: z.string(),
        customerId: z.string(),
        items: z.array(
          z.object({
            productId: z.string(),
            quantity: z.number(),
            price: z.number(),
          })
        ),
        deliveryAddress: z.string(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const orderId = `ORD-${Date.now()}`;
      const totalAmount = input.items.reduce(
        (sum, item) => sum + item.price * item.quantity,
        0
      );

      // Create order
      await db.insert(orders).values({
        id: orderId,
        merchantId: input.merchantId,
        customerId: input.customerId,
        totalAmount,
        status: "pending",
        deliveryAddress: input.deliveryAddress,
        notes: input.notes,
        createdAt: new Date(),
        updatedAt: new Date(),
      });

      // Create order items
      for (const item of input.items) {
        await db.insert(orderItems).values({
          id: `ITEM-${Date.now()}-${Math.random()}`,
          orderId,
          productId: item.productId,
          quantity: item.quantity,
          price: item.price,
        });
      }

      // Log activity
      ctx.logger?.info(`Order created: ${orderId}`, {
        merchantId: input.merchantId,
        customerId: input.customerId,
        totalAmount,
      });

      return { orderId, totalAmount };
    }),

  // Get order by ID
  getOrder: protectedProcedure
    .input(z.object({ orderId: z.string() }))
    .query(async ({ input }) => {
      const order = await db.query.orders.findFirst({
        where: eq(orders.id, input.orderId),
        with: {
          items: true,
          delivery: true,
        },
      });

      return order;
    }),

  // List orders for customer
  listCustomerOrders: protectedProcedure
    .input(z.object({ customerId: z.string() }))
    .query(async ({ input }) => {
      const customerOrders = await db.query.orders.findMany({
        where: eq(orders.customerId, input.customerId),
        orderBy: (orders) => [orders.createdAt],
      });

      return customerOrders;
    }),

  // List orders for merchant
  listMerchantOrders: protectedProcedure
    .input(z.object({ merchantId: z.string() }))
    .query(async ({ input }) => {
      const merchantOrders = await db.query.orders.findMany({
        where: eq(orders.merchantId, input.merchantId),
        orderBy: (orders) => [orders.createdAt],
      });

      return merchantOrders;
    }),

  // Update order status
  updateOrderStatus: protectedProcedure
    .input(
      z.object({
        orderId: z.string(),
        status: z.enum([
          "pending",
          "confirmed",
          "preparing",
          "ready",
          "dispatched",
          "delivered",
          "cancelled",
        ]),
      })
    )
    .mutation(async ({ input, ctx }) => {
      await db
        .update(orders)
        .set({
          status: input.status,
          updatedAt: new Date(),
        })
        .where(eq(orders.id, input.orderId));

      ctx.logger?.info(`Order status updated: ${input.orderId}`, {
        status: input.status,
      });

      return { success: true };
    }),

  // Assign delivery
  assignDelivery: protectedProcedure
    .input(
      z.object({
        orderId: z.string(),
        pilotId: z.string(),
        droneId: z.string(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const deliveryId = `DEL-${Date.now()}`;

      await db.insert(deliveries).values({
        id: deliveryId,
        orderId: input.orderId,
        pilotId: input.pilotId,
        droneId: input.droneId,
        status: "assigned",
        createdAt: new Date(),
        updatedAt: new Date(),
      });

      await db
        .update(orders)
        .set({
          status: "dispatched",
          updatedAt: new Date(),
        })
        .where(eq(orders.id, input.orderId));

      ctx.logger?.info(`Delivery assigned: ${deliveryId}`, {
        orderId: input.orderId,
        pilotId: input.pilotId,
      });

      return { deliveryId };
    }),

  // Cancel order
  cancelOrder: protectedProcedure
    .input(z.object({ orderId: z.string(), reason: z.string() }))
    .mutation(async ({ input, ctx }) => {
      await db
        .update(orders)
        .set({
          status: "cancelled",
          updatedAt: new Date(),
        })
        .where(eq(orders.id, input.orderId));

      ctx.logger?.info(`Order cancelled: ${input.orderId}`, {
        reason: input.reason,
      });

      return { success: true };
    }),

  // Get order statistics
  getOrderStats: protectedProcedure
    .input(z.object({ merchantId: z.string().optional() }))
    .query(async ({ input }) => {
      const query = input.merchantId
        ? db.query.orders.findMany({
            where: eq(orders.merchantId, input.merchantId),
          })
        : db.query.orders.findMany();

      const allOrders = await query;

      const stats = {
        total: allOrders.length,
        pending: allOrders.filter((o) => o.status === "pending").length,
        confirmed: allOrders.filter((o) => o.status === "confirmed").length,
        preparing: allOrders.filter((o) => o.status === "preparing").length,
        ready: allOrders.filter((o) => o.status === "ready").length,
        dispatched: allOrders.filter((o) => o.status === "dispatched").length,
        delivered: allOrders.filter((o) => o.status === "delivered").length,
        cancelled: allOrders.filter((o) => o.status === "cancelled").length,
        totalRevenue: allOrders.reduce((sum, o) => sum + o.totalAmount, 0),
      };

      return stats;
    }),
});
