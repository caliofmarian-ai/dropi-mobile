import { router, publicProcedure, protectedProcedure, adminProcedure } from '../trpc.js';
import { z } from 'zod';

export const supportRouter = router({
  list: publicProcedure.query(async ({ ctx }) => {
    return { message: 'support list endpoint' };
  }),
});
