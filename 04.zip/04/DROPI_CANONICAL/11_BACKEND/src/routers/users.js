import { router, publicProcedure, protectedProcedure, adminProcedure } from '../trpc.js';
import { z } from 'zod';

export const usersRouter = router({
  list: publicProcedure.query(async ({ ctx }) => {
    return { message: 'users list endpoint' };
  }),
});
