import { router } from '../trpc.js';
import { authRouter } from './auth.js';
import { usersRouter } from './users.js';
import { agentsRouter } from './agents.js';
import { issuesRouter } from './issues.js';
import { supportRouter } from './support.js';
import { simulationRouter } from './simulation.js';
import { ordersRouter } from './orders.js';
import { deliveriesRouter } from './deliveries.js';
import { analyticsRouter } from './analytics.js';

export const appRouter = router({
  auth: authRouter,
  users: usersRouter,
  agents: agentsRouter,
  issues: issuesRouter,
  support: supportRouter,
  simulation: simulationRouter,
  orders: ordersRouter,
  deliveries: deliveriesRouter,
  analytics: analyticsRouter,
});

export type AppRouter = typeof appRouter;
