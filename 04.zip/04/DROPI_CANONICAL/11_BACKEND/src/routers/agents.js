import { router, publicProcedure, protectedProcedure, adminProcedure } from '../trpc.js';
import { z } from 'zod';

export const agentsRouter = router({
  list: publicProcedure.query(async ({ ctx }) => {
    return { message: 'agents list endpoint' };
  }),
});
