import { router, publicProcedure, protectedProcedure } from '../trpc.js';
import { z } from 'zod';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';

export const authRouter = router({
  register: publicProcedure
    .input(
      z.object({
        email: z.string().email(),
        password: z.string().min(8),
        name: z.string().min(2),
        role: z.enum(['user', 'agent', 'admin']),
        channel: z.string().optional(),
        agentType: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const { db } = ctx;
      
      // Check if user exists
      const existing = await db.query.users.findFirst({
        where: (users, { eq }) => eq(users.email, input.email),
      });
      
      if (existing) {
        throw new Error('User already exists');
      }
      
      // Hash password
      const hashedPassword = await bcrypt.hash(input.password, 10);
      
      // Create user
      const userId = uuidv4();
      await db.insert(db.schema.users).values({
        id: userId,
        email: input.email,
        password: hashedPassword,
        name: input.name,
        role: input.role,
        channel: input.channel,
        agentType: input.agentType,
        status: 'active',
      });
      
      // Generate token
      const token = jwt.sign(
        {
          userId,
          email: input.email,
          role: input.role,
          channel: input.channel,
          agentType: input.agentType,
        },
        process.env.JWT_SECRET || 'secret',
        { expiresIn: '7d' }
      );
      
      return { token, user: { id: userId, email: input.email, role: input.role } };
    }),

  login: publicProcedure
    .input(
      z.object({
        email: z.string().email(),
        password: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const { db } = ctx;
      
      // Find user
      const user = await db.query.users.findFirst({
        where: (users, { eq }) => eq(users.email, input.email),
      });
      
      if (!user) {
        throw new Error('User not found');
      }
      
      // Check password
      const validPassword = await bcrypt.compare(input.password, user.password);
      if (!validPassword) {
        throw new Error('Invalid password');
      }
      
      // Generate token
      const token = jwt.sign(
        {
          userId: user.id,
          email: user.email,
          role: user.role,
          channel: user.channel,
          agentType: user.agentType,
        },
        process.env.JWT_SECRET || 'secret',
        { expiresIn: '7d' }
      );
      
      return { token, user: { id: user.id, email: user.email, role: user.role } };
    }),

  me: protectedProcedure.query(async ({ ctx }) => {
    return ctx.user;
  }),

  logout: protectedProcedure.mutation(async ({ ctx }) => {
    // Token is invalidated on client side
    return { success: true };
  }),
});
