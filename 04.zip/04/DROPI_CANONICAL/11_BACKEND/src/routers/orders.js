import { router, publicProcedure, protectedProcedure, adminProcedure } from '../trpc.js';
import { z } from 'zod';

export const ordersRouter = router({
  list: publicProcedure.query(async ({ ctx }) => {
    return { message: 'orders list endpoint' };
  }),
});
