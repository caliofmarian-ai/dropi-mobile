import { router, publicProcedure, protectedProcedure, adminProcedure } from '../trpc.js';
import { z } from 'zod';

export const issuesRouter = router({
  list: publicProcedure.query(async ({ ctx }) => {
    return { message: 'issues list endpoint' };
  }),
});
