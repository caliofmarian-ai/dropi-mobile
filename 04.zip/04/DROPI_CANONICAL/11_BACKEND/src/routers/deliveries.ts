import { router, protectedProcedure } from "../trpc";
import { z } from "zod";
import { db } from "../db";
import { deliveries, drones, pilots } from "../db/schema";
import { eq } from "drizzle-orm";

export const deliveriesRouter = router({
  // Start delivery
  startDelivery: protectedProcedure
    .input(
      z.object({
        deliveryId: z.string(),
        startLocation: z.object({ lat: z.number(), lng: z.number() }),
      })
    )
    .mutation(async ({ input, ctx }) => {
      await db
        .update(deliveries)
        .set({
          status: "in_transit",
          startLocation: JSON.stringify(input.startLocation),
          startTime: new Date(),
          updatedAt: new Date(),
        })
        .where(eq(deliveries.id, input.deliveryId));

      ctx.logger?.info(`Delivery started: ${input.deliveryId}`, {
        location: input.startLocation,
      });

      return { success: true };
    }),

  // Update delivery location
  updateDeliveryLocation: protectedProcedure
    .input(
      z.object({
        deliveryId: z.string(),
        location: z.object({ lat: z.number(), lng: z.number() }),
        altitude: z.number().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      await db
        .update(deliveries)
        .set({
          currentLocation: JSON.stringify(input.location),
          altitude: input.altitude,
          updatedAt: new Date(),
        })
        .where(eq(deliveries.id, input.deliveryId));

      return { success: true };
    }),

  // Complete delivery
  completeDelivery: protectedProcedure
    .input(
      z.object({
        deliveryId: z.string(),
        endLocation: z.object({ lat: z.number(), lng: z.number() }),
        signature: z.string().optional(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      await db
        .update(deliveries)
        .set({
          status: "completed",
          endLocation: JSON.stringify(input.endLocation),
          endTime: new Date(),
          signature: input.signature,
          notes: input.notes,
          updatedAt: new Date(),
        })
        .where(eq(deliveries.id, input.deliveryId));

      ctx.logger?.info(`Delivery completed: ${input.deliveryId}`, {
        location: input.endLocation,
      });

      return { success: true };
    }),

  // Get delivery details
  getDelivery: protectedProcedure
    .input(z.object({ deliveryId: z.string() }))
    .query(async ({ input }) => {
      const delivery = await db.query.deliveries.findFirst({
        where: eq(deliveries.id, input.deliveryId),
        with: {
          pilot: true,
          drone: true,
        },
      });

      return delivery;
    }),

  // List active deliveries for pilot
  listPilotDeliveries: protectedProcedure
    .input(z.object({ pilotId: z.string() }))
    .query(async ({ input }) => {
      const pilotDeliveries = await db.query.deliveries.findMany({
        where: eq(deliveries.pilotId, input.pilotId),
        orderBy: (deliveries) => [deliveries.createdAt],
      });

      return pilotDeliveries;
    }),

  // Get delivery statistics
  getDeliveryStats: protectedProcedure
    .input(z.object({ pilotId: z.string().optional() }))
    .query(async ({ input }) => {
      const query = input.pilotId
        ? db.query.deliveries.findMany({
            where: eq(deliveries.pilotId, input.pilotId),
          })
        : db.query.deliveries.findMany();

      const allDeliveries = await query;

      const stats = {
        total: allDeliveries.length,
        assigned: allDeliveries.filter((d) => d.status === "assigned").length,
        inTransit: allDeliveries.filter((d) => d.status === "in_transit")
          .length,
        completed: allDeliveries.filter((d) => d.status === "completed").length,
        failed: allDeliveries.filter((d) => d.status === "failed").length,
        averageTime: calculateAverageDeliveryTime(allDeliveries),
      };

      return stats;
    }),

  // Report delivery issue
  reportIssue: protectedProcedure
    .input(
      z.object({
        deliveryId: z.string(),
        issueType: z.enum([
          "drone_malfunction",
          "weather",
          "customer_unavailable",
          "address_not_found",
          "other",
        ]),
        description: z.string(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      await db
        .update(deliveries)
        .set({
          status: "failed",
          issueType: input.issueType,
          issueDescription: input.description,
          updatedAt: new Date(),
        })
        .where(eq(deliveries.id, input.deliveryId));

      ctx.logger?.warn(`Delivery issue reported: ${input.deliveryId}`, {
        issueType: input.issueType,
      });

      return { success: true };
    }),

  // Retry delivery
  retryDelivery: protectedProcedure
    .input(
      z.object({
        deliveryId: z.string(),
        newPilotId: z.string(),
        newDroneId: z.string(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      await db
        .update(deliveries)
        .set({
          status: "assigned",
          pilotId: input.newPilotId,
          droneId: input.newDroneId,
          updatedAt: new Date(),
        })
        .where(eq(deliveries.id, input.deliveryId));

      ctx.logger?.info(`Delivery retried: ${input.deliveryId}`, {
        pilotId: input.newPilotId,
      });

      return { success: true };
    }),
});

function calculateAverageDeliveryTime(
  deliveries: any[]
): number | null {
  const completedDeliveries = deliveries.filter(
    (d) => d.status === "completed" && d.startTime && d.endTime
  );

  if (completedDeliveries.length === 0) return null;

  const totalTime = completedDeliveries.reduce((sum, d) => {
    const time =
      (new Date(d.endTime).getTime() - new Date(d.startTime).getTime()) / 1000;
    return sum + time;
  }, 0);

  return Math.round(totalTime / completedDeliveries.length);
}
