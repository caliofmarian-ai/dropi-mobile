import {
  mysqlTable,
  varchar,
  int,
  text,
  timestamp,
  boolean,
  decimal,
  json,
  enum as mysqlEnum,
  primaryKey,
  index,
  uniqueIndex,
} from 'drizzle-orm/mysql-core';

// Users table
export const users = mysqlTable(
  'users',
  {
    id: varchar('id', { length: 36 }).primaryKey(),
    email: varchar('email', { length: 255 }).notNull().unique(),
    password: varchar('password', { length: 255 }).notNull(),
    name: varchar('name', { length: 255 }).notNull(),
    role: varchar('role', { length: 50 }).notNull(), // admin, user, agent
    channel: varchar('channel', { length: 50 }), // C1, C2, C3, Admin
    agentType: varchar('agent_type', { length: 100 }), // Customer, Merchant, Pilot, etc.
    status: varchar('status', { length: 50 }).default('active'), // active, inactive, suspended
    metadata: json('metadata'),
    createdAt: timestamp('created_at').defaultNow(),
    updatedAt: timestamp('updated_at').defaultNow().onUpdateNow(),
  },
  (table) => ({
    emailIdx: uniqueIndex('email_idx').on(table.email),
    roleIdx: index('role_idx').on(table.role),
    channelIdx: index('channel_idx').on(table.channel),
  })
);

// Agents table
export const agents = mysqlTable(
  'agents',
  {
    id: varchar('id', { length: 36 }).primaryKey(),
    name: varchar('name', { length: 255 }).notNull(),
    type: varchar('type', { length: 100 }).notNull(), // Customer, Merchant, Pilot, etc.
    channel: varchar('channel', { length: 50 }).notNull(), // C1, C2, C3, Admin
    description: text('description'),
    capabilities: json('capabilities'),
    status: varchar('status', { length: 50 }).default('active'),
    createdAt: timestamp('created_at').defaultNow(),
    updatedAt: timestamp('updated_at').defaultNow().onUpdateNow(),
  },
  (table) => ({
    typeIdx: index('type_idx').on(table.type),
    channelIdx: index('channel_idx').on(table.channel),
  })
);

// Agent executions table
export const agentExecutions = mysqlTable(
  'agent_executions',
  {
    id: varchar('id', { length: 36 }).primaryKey(),
    agentId: varchar('agent_id', { length: 36 }).notNull(),
    executionTime: timestamp('execution_time').defaultNow(),
    status: varchar('status', { length: 50 }).notNull(), // success, failed, pending
    result: json('result'),
    error: text('error'),
    duration: int('duration'), // milliseconds
    createdAt: timestamp('created_at').defaultNow(),
  },
  (table) => ({
    agentIdIdx: index('agent_id_idx').on(table.agentId),
    statusIdx: index('status_idx').on(table.status),
  })
);

// Issues table
export const issues = mysqlTable(
  'issues',
  {
    id: varchar('id', { length: 36 }).primaryKey(),
    agentId: varchar('agent_id', { length: 36 }).notNull(),
    title: varchar('title', { length: 255 }).notNull(),
    description: text('description'),
    severity: varchar('severity', { length: 50 }).notNull(), // critical, high, medium, low
    status: varchar('status', { length: 50 }).default('open'), // open, in_progress, resolved, closed
    metadata: json('metadata'),
    createdAt: timestamp('created_at').defaultNow(),
    updatedAt: timestamp('updated_at').defaultNow().onUpdateNow(),
  },
  (table) => ({
    agentIdIdx: index('agent_id_idx').on(table.agentId),
    severityIdx: index('severity_idx').on(table.severity),
    statusIdx: index('status_idx').on(table.status),
  })
);

// Support tickets table
export const supportTickets = mysqlTable(
  'support_tickets',
  {
    id: varchar('id', { length: 36 }).primaryKey(),
    userId: varchar('user_id', { length: 36 }).notNull(),
    issueId: varchar('issue_id', { length: 36 }),
    title: varchar('title', { length: 255 }).notNull(),
    description: text('description'),
    category: varchar('category', { length: 100 }),
    priority: varchar('priority', { length: 50 }).default('medium'), // critical, high, medium, low
    status: varchar('status', { length: 50 }).default('open'), // open, in_progress, resolved, closed
    assignedTo: varchar('assigned_to', { length: 36 }),
    resolution: text('resolution'),
    createdAt: timestamp('created_at').defaultNow(),
    updatedAt: timestamp('updated_at').defaultNow().onUpdateNow(),
    resolvedAt: timestamp('resolved_at'),
  },
  (table) => ({
    userIdIdx: index('user_id_idx').on(table.userId),
    statusIdx: index('status_idx').on(table.status),
    priorityIdx: index('priority_idx').on(table.priority),
  })
);

// Support metrics table
export const supportMetrics = mysqlTable(
  'support_metrics',
  {
    id: varchar('id', { length: 36 }).primaryKey(),
    date: timestamp('date').notNull(),
    totalTickets: int('total_tickets').default(0),
    openTickets: int('open_tickets').default(0),
    resolvedTickets: int('resolved_tickets').default(0),
    avgResolutionTime: int('avg_resolution_time'), // minutes
    avgResponseTime: int('avg_response_time'), // minutes
    satisfactionScore: decimal('satisfaction_score', { precision: 3, scale: 2 }),
    createdAt: timestamp('created_at').defaultNow(),
  },
  (table) => ({
    dateIdx: index('date_idx').on(table.date),
  })
);

// Simulation runs table
export const simulationRuns = mysqlTable(
  'simulation_runs',
  {
    id: varchar('id', { length: 36 }).primaryKey(),
    startDate: timestamp('start_date').notNull(),
    endDate: timestamp('end_date'),
    status: varchar('status', { length: 50 }).default('running'), // running, completed, failed
    totalAgentExecutions: int('total_agent_executions').default(0),
    totalIssuesDetected: int('total_issues_detected').default(0),
    totalTicketsCreated: int('total_tickets_created').default(0),
    metrics: json('metrics'),
    createdAt: timestamp('created_at').defaultNow(),
  },
  (table) => ({
    statusIdx: index('status_idx').on(table.status),
  })
);

// Audit logs table
export const auditLogs = mysqlTable(
  'audit_logs',
  {
    id: varchar('id', { length: 36 }).primaryKey(),
    userId: varchar('user_id', { length: 36 }),
    action: varchar('action', { length: 255 }).notNull(),
    resource: varchar('resource', { length: 255 }),
    resourceId: varchar('resource_id', { length: 36 }),
    changes: json('changes'),
    ipAddress: varchar('ip_address', { length: 45 }),
    userAgent: text('user_agent'),
    createdAt: timestamp('created_at').defaultNow(),
  },
  (table) => ({
    userIdIdx: index('user_id_idx').on(table.userId),
    actionIdx: index('action_idx').on(table.action),
    createdAtIdx: index('created_at_idx').on(table.createdAt),
  })
);

// Orders table
export const orders = mysqlTable(
  'orders',
  {
    id: varchar('id', { length: 36 }).primaryKey(),
    customerId: varchar('customer_id', { length: 36 }).notNull(),
    merchantId: varchar('merchant_id', { length: 36 }).notNull(),
    status: varchar('status', { length: 50 }).default('pending'),
    totalAmount: decimal('total_amount', { precision: 10, scale: 2 }),
    items: json('items'),
    deliveryAddress: text('delivery_address'),
    createdAt: timestamp('created_at').defaultNow(),
    updatedAt: timestamp('updated_at').defaultNow().onUpdateNow(),
  },
  (table) => ({
    customerIdIdx: index('customer_id_idx').on(table.customerId),
    merchantIdIdx: index('merchant_id_idx').on(table.merchantId),
    statusIdx: index('status_idx').on(table.status),
  })
);

// Deliveries table
export const deliveries = mysqlTable(
  'deliveries',
  {
    id: varchar('id', { length: 36 }).primaryKey(),
    orderId: varchar('order_id', { length: 36 }).notNull(),
    pilotId: varchar('pilot_id', { length: 36 }),
    droneId: varchar('drone_id', { length: 36 }),
    status: varchar('status', { length: 50 }).default('pending'),
    pickupLocation: text('pickup_location'),
    deliveryLocation: text('delivery_location'),
    estimatedTime: int('estimated_time'), // minutes
    actualTime: int('actual_time'), // minutes
    createdAt: timestamp('created_at').defaultNow(),
    updatedAt: timestamp('updated_at').defaultNow().onUpdateNow(),
  },
  (table) => ({
    orderIdIdx: index('order_id_idx').on(table.orderId),
    pilotIdIdx: index('pilot_id_idx').on(table.pilotId),
    statusIdx: index('status_idx').on(table.status),
  })
);

// DronePort locations table
export const droneports = mysqlTable(
  'droneports',
  {
    id: varchar('id', { length: 36 }).primaryKey(),
    name: varchar('name', { length: 255 }).notNull(),
    location: text('location'),
    latitude: decimal('latitude', { precision: 10, scale: 8 }),
    longitude: decimal('longitude', { precision: 11, scale: 8 }),
    capacity: int('capacity'),
    status: varchar('status', { length: 50 }).default('active'),
    metadata: json('metadata'),
    createdAt: timestamp('created_at').defaultNow(),
    updatedAt: timestamp('updated_at').defaultNow().onUpdateNow(),
  },
  (table) => ({
    nameIdx: index('name_idx').on(table.name),
    statusIdx: index('status_idx').on(table.status),
  })
);
