import mysql from 'mysql2/promise';
import { drizzle } from 'drizzle-orm/mysql2';
import * as schema from './schema.js';

let db = null;
let pool = null;

export async function initializeDatabase() {
  if (db) return db;
  
  const connectionConfig = {
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'dropi',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
    enableKeepAlive: true,
    keepAliveInitialDelayMs: 0,
  };
  
  try {
    pool = await mysql.createPool(connectionConfig);
    db = drizzle(pool, { schema, mode: 'default' });
    console.log('✅ Database connected');
    return db;
  } catch (err) {
    console.error('❌ Database connection failed:', err);
    throw err;
  }
}

export function getDatabase() {
  if (!db) {
    throw new Error('Database not initialized. Call initializeDatabase() first.');
  }
  return db;
}

export async function closeDatabase() {
  if (pool) {
    await pool.end();
    console.log('✅ Database connection closed');
  }
}

export { schema };
