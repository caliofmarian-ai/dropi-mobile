/**
 * Dropi AI Agents - 29 Autonomous Agents for Platform Testing
 * Each agent simulates real user behavior across all roles and channels
 */

const agents = {
  // C1 MARKETPLACE AGENTS (6)
  C1_CUSTOMER: {
    id: 'agent_c1_customer_001',
    name: 'C1 Customer Agent',
    role: 'customer',
    channel: 'C1',
    description: 'Simulates customer behavior: browsing, ordering, tracking',
    actions: [
      'browse_merchants',
      'search_products',
      'add_to_cart',
      'place_order',
      'track_delivery',
      'rate_delivery',
      'leave_review',
    ],
    frequency: 'every 2 hours',
  },

  C1_MERCHANT: {
    id: 'agent_c1_merchant_001',
    name: 'C1 Merchant Agent',
    role: 'merchant',
    channel: 'C1',
    description: 'Simulates merchant behavior: managing store, processing orders',
    actions: [
      'check_orders',
      'update_inventory',
      'confirm_orders',
      'prepare_orders',
      'view_analytics',
      'manage_menu',
      'respond_to_reviews',
    ],
    frequency: 'every 1 hour',
  },

  C1_PILOT: {
    id: 'agent_c1_pilot_001',
    name: 'C1 Pilot Agent',
    role: 'pilot',
    channel: 'C1',
    description: 'Simulates pilot behavior: accepting deliveries, flying drones',
    actions: [
      'check_available_deliveries',
      'accept_delivery',
      'start_flight',
      'update_location',
      'complete_delivery',
      'log_issues',
      'view_earnings',
    ],
    frequency: 'every 30 minutes',
  },

  C1_OPERATOR: {
    id: 'agent_c1_operator_001',
    name: 'C1 Operator Agent',
    role: 'operator',
    channel: 'C1',
    description: 'Simulates operator behavior: managing operations',
    actions: [
      'monitor_deliveries',
      'manage_pilots',
      'resolve_issues',
      'view_reports',
      'optimize_routes',
      'manage_zones',
    ],
    frequency: 'every 1 hour',
  },

  C1_FINANCIAL: {
    id: 'agent_c1_financial_001',
    name: 'C1 Financial Manager Agent',
    role: 'financial_manager',
    channel: 'C1',
    description: 'Simulates financial manager behavior: tracking payments, revenue',
    actions: [
      'view_revenue',
      'process_payments',
      'generate_invoices',
      'view_analytics',
      'manage_commissions',
      'reconcile_accounts',
    ],
    frequency: 'every 4 hours',
  },

  C1_ANALYTICS: {
    id: 'agent_c1_analytics_001',
    name: 'C1 Analytics Manager Agent',
    role: 'analytics_manager',
    channel: 'C1',
    description: 'Simulates analytics manager behavior: analyzing data',
    actions: [
      'view_dashboards',
      'generate_reports',
      'analyze_trends',
      'export_data',
      'create_alerts',
      'monitor_kpis',
    ],
    frequency: 'every 6 hours',
  },

  // C2 CONTRACTED OPERATIONS AGENTS (6)
  C2_OPERATOR: {
    id: 'agent_c2_operator_001',
    name: 'C2 COS Operator Agent',
    role: 'operator',
    channel: 'C2',
    description: 'Simulates C2 operator behavior: managing contracted operations',
    actions: [
      'manage_contracts',
      'assign_deliveries',
      'monitor_fleet',
      'track_compliance',
      'manage_zones',
      'optimize_routes',
    ],
    frequency: 'every 1 hour',
  },

  C2_PILOT: {
    id: 'agent_c2_pilot_001',
    name: 'C2 COS Pilot Agent',
    role: 'pilot',
    channel: 'C2',
    description: 'Simulates C2 pilot behavior: executing contracted deliveries',
    actions: [
      'accept_contracts',
      'execute_delivery',
      'log_compliance',
      'report_issues',
      'track_time',
    ],
    frequency: 'every 30 minutes',
  },

  C2_FINANCIAL: {
    id: 'agent_c2_financial_001',
    name: 'C2 Financial Manager Agent',
    role: 'financial_manager',
    channel: 'C2',
    description: 'Simulates C2 financial manager behavior',
    actions: [
      'manage_contracts',
      'process_payments',
      'track_costs',
      'generate_reports',
    ],
    frequency: 'every 4 hours',
  },

  C2_ANALYTICS: {
    id: 'agent_c2_analytics_001',
    name: 'C2 Analytics Manager Agent',
    role: 'analytics_manager',
    channel: 'C2',
    description: 'Simulates C2 analytics manager behavior',
    actions: [
      'analyze_performance',
      'generate_reports',
      'monitor_compliance',
      'create_alerts',
    ],
    frequency: 'every 6 hours',
  },

  C2_MANAGER: {
    id: 'agent_c2_manager_001',
    name: 'C2 Manager Agent',
    role: 'manager',
    channel: 'C2',
    description: 'Simulates C2 manager behavior: overseeing operations',
    actions: [
      'review_operations',
      'approve_contracts',
      'manage_team',
      'view_analytics',
    ],
    frequency: 'every 2 hours',
  },

  C2_COORDINATOR: {
    id: 'agent_c2_coordinator_001',
    name: 'C2 Coordinator Agent',
    role: 'coordinator',
    channel: 'C2',
    description: 'Simulates C2 coordinator behavior: coordinating operations',
    actions: [
      'coordinate_deliveries',
      'manage_schedules',
      'communicate_updates',
      'resolve_conflicts',
    ],
    frequency: 'every 1 hour',
  },

  // C3 EMERGENCY OPERATIONS AGENTS (6)
  C3_RESPONDER: {
    id: 'agent_c3_responder_001',
    name: 'C3 Emergency Responder Agent',
    role: 'responder',
    channel: 'C3',
    description: 'Simulates emergency responder behavior: responding to emergencies',
    actions: [
      'receive_alert',
      'assess_situation',
      'deploy_drone',
      'provide_support',
      'log_incident',
      'report_outcome',
    ],
    frequency: 'every 15 minutes',
  },

  C3_PILOT: {
    id: 'agent_c3_pilot_001',
    name: 'C3 Emergency Pilot Agent',
    role: 'pilot',
    channel: 'C3',
    description: 'Simulates C3 pilot behavior: emergency response flights',
    actions: [
      'standby',
      'receive_emergency',
      'launch_immediately',
      'navigate_safely',
      'deliver_supplies',
      'return_safely',
    ],
    frequency: 'every 20 minutes',
  },

  C3_FINANCIAL: {
    id: 'agent_c3_financial_001',
    name: 'C3 Financial Manager Agent',
    role: 'financial_manager',
    channel: 'C3',
    description: 'Simulates C3 financial manager behavior',
    actions: [
      'track_emergency_costs',
      'manage_budget',
      'process_claims',
      'generate_reports',
    ],
    frequency: 'every 4 hours',
  },

  C3_ANALYTICS: {
    id: 'agent_c3_analytics_001',
    name: 'C3 Analytics Manager Agent',
    role: 'analytics_manager',
    channel: 'C3',
    description: 'Simulates C3 analytics manager behavior',
    actions: [
      'analyze_response_times',
      'track_success_rates',
      'generate_reports',
      'identify_improvements',
    ],
    frequency: 'every 6 hours',
  },

  C3_MANAGER: {
    id: 'agent_c3_manager_001',
    name: 'C3 Manager Agent',
    role: 'manager',
    channel: 'C3',
    description: 'Simulates C3 manager behavior: overseeing emergency operations',
    actions: [
      'monitor_readiness',
      'manage_resources',
      'review_incidents',
      'plan_improvements',
    ],
    frequency: 'every 2 hours',
  },

  C3_COORDINATOR: {
    id: 'agent_c3_coordinator_001',
    name: 'C3 Coordinator Agent',
    role: 'coordinator',
    channel: 'C3',
    description: 'Simulates C3 coordinator behavior: coordinating emergency response',
    actions: [
      'receive_calls',
      'dispatch_resources',
      'coordinate_teams',
      'communicate_updates',
    ],
    frequency: 'every 30 minutes',
  },

  // ADMIN/GOVERNANCE AGENTS (5)
  ADMIN: {
    id: 'agent_admin_001',
    name: 'Admin Agent',
    role: 'admin',
    channel: 'ADMIN',
    description: 'Simulates admin behavior: system administration',
    actions: [
      'monitor_system',
      'manage_users',
      'view_analytics',
      'manage_settings',
      'handle_support',
    ],
    frequency: 'every 1 hour',
  },

  SUPER_ADMIN: {
    id: 'agent_super_admin_001',
    name: 'Super Admin Agent',
    role: 'super_admin',
    channel: 'ADMIN',
    description: 'Simulates super admin behavior: platform oversight',
    actions: [
      'review_operations',
      'manage_admins',
      'approve_changes',
      'view_reports',
      'manage_governance',
    ],
    frequency: 'every 2 hours',
  },

  COMPLIANCE: {
    id: 'agent_compliance_001',
    name: 'Compliance Officer Agent',
    role: 'compliance_officer',
    channel: 'ADMIN',
    description: 'Simulates compliance officer behavior: ensuring compliance',
    actions: [
      'audit_operations',
      'check_regulations',
      'generate_reports',
      'flag_issues',
      'approve_policies',
    ],
    frequency: 'every 4 hours',
  },

  ACCOUNTANT: {
    id: 'agent_accountant_001',
    name: 'Accountant Agent',
    role: 'accountant',
    channel: 'ADMIN',
    description: 'Simulates accountant behavior: financial management',
    actions: [
      'reconcile_accounts',
      'generate_reports',
      'manage_invoices',
      'track_expenses',
      'audit_transactions',
    ],
    frequency: 'every 4 hours',
  },

  BI_SPECIALIST: {
    id: 'agent_bi_specialist_001',
    name: 'BI Specialist Agent',
    role: 'bi_specialist',
    channel: 'ADMIN',
    description: 'Simulates BI specialist behavior: data analysis',
    actions: [
      'analyze_data',
      'create_dashboards',
      'generate_insights',
      'predict_trends',
      'optimize_operations',
    ],
    frequency: 'every 6 hours',
  },
};

module.exports = agents;
