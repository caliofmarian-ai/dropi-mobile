import React from 'react'
import { Link } from 'react-router-dom'

export default function Navigation() {
  return (
    <nav className="bg-white shadow-md">
      <div className="container-custom flex justify-between items-center py-4">
        <Link to="/" className="text-2xl font-bold text-primary">
          DROPi
        </Link>
        <div className="hidden md:flex space-x-8">
          <Link to="/how-it-works" className="hover:text-primary">How It Works</Link>
          <Link to="/customers" className="hover:text-primary">Customers</Link>
          <Link to="/merchants" className="hover:text-primary">Merchants</Link>
          <Link to="/partners" className="hover:text-primary">Partners</Link>
          <Link to="/pricing" className="hover:text-primary">Pricing</Link>
          <Link to="/blog" className="hover:text-primary">Blog</Link>
        </div>
        <Link to="/contact" className="btn-primary">Get Started</Link>
      </div>
    </nav>
  )
}
