import React from 'react'

export default function PrivacyPage() {
  return (
    <div className="container-custom py-16">
      <h1 className="section-title">PrivacyPage</h1>
      <p className="text-gray-600">Page content coming soon...</p>
    </div>
  )
}
