import React from 'react'

export default function TermsPage() {
  return (
    <div className="container-custom py-16">
      <h1 className="section-title">TermsPage</h1>
      <p className="text-gray-600">Page content coming soon...</p>
    </div>
  )
}
