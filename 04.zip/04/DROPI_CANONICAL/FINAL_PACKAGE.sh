#!/bin/bash

# DROPi Final Package Script
# Creates complete downloadable package with all components

set -e

echo "🎯 Creating DROPi Final Package..."
echo ""

# Create package directory
PACKAGE_DIR="/home/ubuntu/DROPI_FINAL_PACKAGE"
rm -rf "$PACKAGE_DIR"
mkdir -p "$PACKAGE_DIR"

# Copy all components
echo "📦 Packaging components..."
cp -r /home/ubuntu/DROPI_CANONICAL/* "$PACKAGE_DIR/"

# Create installation guide
cat > "$PACKAGE_DIR/INSTALLATION_GUIDE.md" << 'EOF'
# DROPi Platform - Installation Guide

## Quick Start (5 minutes)

### Prerequisites
- Docker & Docker Compose
- Node.js 18+
- npm or pnpm

### Installation Steps

1. **Extract the package**
   ```bash
   unzip DROPI_FINAL_PACKAGE.zip
   cd DROPI_FINAL_PACKAGE
   ```

2. **Start with Docker**
   ```bash
   docker-compose up -d
   ```

3. **Access applications**
   - Website: http://localhost:3000
   - Mobile App: http://localhost:3001
   - Admin Dashboard: http://localhost:3002
   - API: http://localhost:3003

4. **Run AI Simulation**
   ```bash
   cd 08_AI_SIMULATION
   node orchestrator.js
   ```

## Manual Installation

### Backend Setup
```bash
cd 11_BACKEND
npm install
npm run dev
```

### Mobile App Setup
```bash
cd 05_MOBILE_APP/react-native
npm install
npm start
```

### Website Setup
```bash
cd 06_WEBSITE/react
npm install
npm run dev
```

## Configuration

1. Copy `.env.example` to `.env`
2. Update database credentials
3. Set API keys and secrets
4. Configure OAuth settings

## Database Setup

```bash
cd 11_BACKEND
npm run db:push
npm run db:seed
```

## Testing

```bash
# Run backend tests
cd 11_BACKEND
npm run test

# Run mobile app tests
cd 05_MOBILE_APP/react-native
npm run test

# Run website tests
cd 06_WEBSITE/react
npm run test
```

## Deployment

### Production Deployment
```bash
docker-compose -f docker-compose.prod.yml up -d
```

### Cloud Deployment
- AWS: See `09_DEPLOYMENT/AWS_DEPLOYMENT.md`
- GCP: See `09_DEPLOYMENT/GCP_DEPLOYMENT.md`
- Azure: See `09_DEPLOYMENT/AZURE_DEPLOYMENT.md`

## Support

For issues and support:
1. Check `12_DOCUMENTATION/TROUBLESHOOTING.md`
2. Review logs in `logs/` directory
3. Contact support team

## License

DROPi Platform © 2026. All rights reserved.
EOF

# Create quick reference
cat > "$PACKAGE_DIR/QUICK_REFERENCE.md" << 'EOF'
# DROPi Quick Reference

## Project Structure
```
DROPI_FINAL_PACKAGE/
├── 01_CANONICAL_DOCS/      ← 166 specification documents
├── 02_ARCHITECTURE/        ← System design diagrams
├── 03_DATABASE/            ← Schema and migrations
├── 04_API/                 ← API documentation
├── 05_MOBILE_APP/          ← React Native application
├── 06_WEBSITE/             ← Marketing website
├── 07_ADMIN_DASHBOARD/     ← Admin control panel
├── 08_AI_SIMULATION/       ← 29 AI agents
├── 09_DEPLOYMENT/          ← Docker and cloud configs
├── 10_ASSETS/              ← Images and diagrams
├── 11_BACKEND/             ← Node.js API server
├── 12_DOCUMENTATION/       ← Guides and references
└── README.md               ← Start here
```

## Key Commands

### Start Everything
```bash
docker-compose up -d
```

### Stop Everything
```bash
docker-compose down
```

### View Logs
```bash
docker-compose logs -f
```

### Run AI Simulation
```bash
cd 08_AI_SIMULATION
node orchestrator.js
```

### Access Services
- Website: http://localhost:3000
- Mobile API: http://localhost:3001
- Admin: http://localhost:3002
- Backend API: http://localhost:3003

## Important Files

- `docker-compose.yml` - Main deployment config
- `11_BACKEND/.env.example` - Backend configuration
- `05_MOBILE_APP/app.json` - Mobile app config
- `06_WEBSITE/vite.config.js` - Website config

## Troubleshooting

### Port Already in Use
```bash
# Change ports in docker-compose.yml
# Or kill existing process:
lsof -i :3000
kill -9 <PID>
```

### Database Connection Failed
```bash
# Check MySQL is running:
docker ps | grep mysql

# Reset database:
docker-compose down -v
docker-compose up -d
```

### API Not Responding
```bash
# Check logs:
docker-compose logs backend

# Restart service:
docker-compose restart backend
```

## Next Steps

1. Read `01_CANONICAL_DOCS/` for complete specifications
2. Review `02_ARCHITECTURE/SYSTEM_ARCHITECTURE.md`
3. Check `12_DOCUMENTATION/DEPLOYMENT_GUIDE.md`
4. Run AI simulation: `cd 08_AI_SIMULATION && node orchestrator.js`
5. Access admin dashboard at http://localhost:3002

## Support

- Documentation: See `12_DOCUMENTATION/`
- Issues: Check `logs/` directory
- API Docs: See `04_API/`
- Troubleshooting: See `12_DOCUMENTATION/TROUBLESHOOTING.md`
EOF

# Create README
cat > "$PACKAGE_DIR/README_FIRST.md" << 'EOF'
# 🚀 DROPi Platform - Complete Package

Welcome to DROPi! This is your complete, production-ready drone delivery platform.

## What's Included

✅ **Fully Functional Applications**
- 📱 Mobile App (React Native) - iOS/Android
- 🌐 Website (React) - Marketing & landing pages
- 🎛️ Admin Dashboard (React) - Platform control
- 🔌 Backend API (Node.js + tRPC) - Complete server

✅ **AI Simulation System**
- 🤖 29 Autonomous Agents - All roles across 4 channels
- 📊 30-Day Simulation - Comprehensive testing
- 📈 Metrics & Analytics - Performance tracking
- 🎯 Issue Detection - Automated problem identification

✅ **Complete Documentation**
- 📖 166 Canonical Documents - Full specifications
- 📊 System Architecture - Technical design
- 🗺️ Deployment Guides - Production ready
- 📚 API Reference - Complete documentation

✅ **Production Ready**
- 🐳 Docker Setup - One-command deployment
- 🔒 Security Configuration - SSL/TLS ready
- 📊 Monitoring - Built-in analytics
- 🔄 CI/CD Ready - GitHub Actions included

## Quick Start (5 Minutes)

### 1. Start Everything
```bash
docker-compose up -d
```

### 2. Access Applications
- Website: http://localhost:3000
- Mobile App: http://localhost:3001
- Admin Dashboard: http://localhost:3002
- API: http://localhost:3003

### 3. Run AI Simulation
```bash
cd 08_AI_SIMULATION
node orchestrator.js
```

## Documentation

Start with these files in order:

1. **INSTALLATION_GUIDE.md** - How to set up
2. **QUICK_REFERENCE.md** - Common commands
3. **01_CANONICAL_DOCS/** - Full specifications
4. **02_ARCHITECTURE/SYSTEM_ARCHITECTURE.md** - Technical design
5. **12_DOCUMENTATION/** - Detailed guides

## Project Structure

```
├── 01_CANONICAL_DOCS/    ← 166 specification documents
├── 02_ARCHITECTURE/      ← System design & diagrams
├── 03_DATABASE/          ← Database schema
├── 04_API/               ← API documentation
├── 05_MOBILE_APP/        ← React Native app
├── 06_WEBSITE/           ← React website
├── 07_ADMIN_DASHBOARD/   ← Admin panel
├── 08_AI_SIMULATION/     ← 29 AI agents
├── 09_DEPLOYMENT/        ← Docker & cloud
├── 10_ASSETS/            ← Images & diagrams
├── 11_BACKEND/           ← Node.js API
└── 12_DOCUMENTATION/     ← Guides & references
```

## Key Features

🎯 **Multi-Channel Operations**
- C1 Marketplace - Customer-merchant marketplace
- C2 Contracted Operations - Business logistics
- C3 Emergency Operations - Emergency response
- Admin - Platform governance

🤖 **AI-Powered Testing**
- 29 autonomous agents
- 1-month simulation
- Automated issue detection
- Performance metrics

📊 **Complete Analytics**
- Real-time dashboards
- Performance tracking
- Issue management
- Financial reporting

🔒 **Enterprise Security**
- Role-based access control
- Audit logging
- Compliance tracking
- Data encryption

## Support & Help

- **Installation Issues**: See INSTALLATION_GUIDE.md
- **Configuration**: Check .env.example files
- **API Documentation**: See 04_API/
- **Troubleshooting**: See 12_DOCUMENTATION/TROUBLESHOOTING.md
- **Architecture**: See 02_ARCHITECTURE/

## Next Steps

1. ✅ Extract this package
2. ✅ Run `docker-compose up -d`
3. ✅ Access http://localhost:3000
4. ✅ Read INSTALLATION_GUIDE.md
5. ✅ Explore the admin dashboard
6. ✅ Run AI simulation

## Important Notes

- All data is stored in Docker volumes
- Backup your database regularly
- Update credentials in .env files
- Review security settings before production
- Check logs for any issues

---

**Ready to launch DROPi? Start with `docker-compose up -d`!** 🚀

For detailed information, see INSTALLATION_GUIDE.md
EOF

# Create checksums
echo "📋 Creating checksums..."
cd "$PACKAGE_DIR"
find . -type f -name "*.md" -o -name "*.js" -o -name "*.json" | head -20 | xargs md5sum > CHECKSUMS.md5

# Create final ZIP
echo "📦 Creating final ZIP package..."
cd /home/ubuntu
zip -r DROPI_FINAL_PACKAGE_COMPLETE.zip DROPI_FINAL_PACKAGE/

# Show summary
echo ""
echo "✅ PACKAGE COMPLETE!"
echo ""
echo "📊 Package Summary:"
du -sh DROPI_FINAL_PACKAGE/
echo ""
echo "📦 Files created:"
ls -lh DROPI_FINAL_PACKAGE_COMPLETE.zip
echo ""
echo "🎯 Next steps:"
echo "1. Download: DROPI_FINAL_PACKAGE_COMPLETE.zip"
echo "2. Extract to your location"
echo "3. Run: docker-compose up -d"
echo "4. Access: http://localhost:3000"
echo ""
echo "✨ DROPi is ready for deployment!"
